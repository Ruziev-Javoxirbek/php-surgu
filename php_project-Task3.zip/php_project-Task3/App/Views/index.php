<?php
for ($i = 0; $i < count($data['arr']); $i++) {
    echo "<h2>[".$i."] = ".$data['arr'][$i]."</h2>";
}
?>
