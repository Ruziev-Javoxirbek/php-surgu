<?php

namespace App\Models;

class UserModel extends \Framework\SQLModel
{
    protected $table="users";
}